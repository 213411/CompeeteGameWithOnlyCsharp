﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class Actor
    {
        public int x;
        public int y;
        public int indeximg = 0;
    
    }
    class goralla
    {
        public int x;
        public int y;
        public int indeximg = 0;

    }
 
    class ActorL
    {
        public int x;
        public int y;
        public int indeximg = 0;
   
    }
    class Bird
    {
        public int x;
        public int y;
        public int fd = 1;
        public int indeximg = 0;

    }
    class lion
    {
        public int x=500;
        public int y=300;
        public int fm = 1;
        public int indeximg = 0;

    }
    class lionl
    {
        public int x = 500;
        public int y = 300;
        public int fm = 1;
        public int indeximg = 0;

    }
    class egg
    {
        public int x;
        public int y;
        public int indeximg = 0;
        public int speed = 0;

    }
    class ball
    {
        public int x=100;
        public int y=-300;
       

    }
    class snake
    {
        public int x = 450;
        public int y ;
        public int indeximg = 0;


    }
    class poison
    {
        public int x ;
        public int y;
        public int flagdraw = 1;


    }
    class Rock
    {
        public int x;
        public int y;
        public int flagdraw = 1;


    }
    class singleb
    {
        public int x=10000;
        public int y=20000;
        public int flagdraw = 0;


    }
    class doubleb
    {
        public int x=1000;
        public int y=22222;
        public int flagdraw = 0;


    }
    class fire
    {
        public int x;
        public int y;
        public int flagdraw = 0;


    }
    class denasor
    {
        public int x;
        public int y;
        public int flagdraw = 0;
        public int indeximg = 0;


    }
    class laser
    {
        public int x;
        public int y;
        public int x2;
        public int y2=10000;



    }
    class tdance
    {
        public int x;
        public int y;
        public int indeximg = 0;

    }

    public partial class Form1 : Form
    {
        List<Bitmap> actimag = new List<Bitmap>();//tiger right
        List<Bird> b = new List<Bird>();
        List<Bitmap> actimag2 = new List<Bitmap>();//tiger left 
        List<Bitmap> actimag3 = new List<Bitmap>();//for bird
        List<Bitmap> actimag4 = new List<Bitmap>();//for egg
        List<Bitmap> actimag5 = new List<Bitmap>();//for lion right
        List<Bitmap> actimag6 = new List<Bitmap>();//for lion left
        List<Bitmap> actimag7 = new List<Bitmap>();//for the snake
        List<Bitmap> actimag8 = new List<Bitmap>();//for the goralla right
        List<Bitmap> actimag9 = new List<Bitmap>();//for the goralla left
        List<Bitmap> actimag10 = new List<Bitmap>();//for the goralla Attack
        List<Bitmap> actimag11 = new List<Bitmap>();//for the denasor
             //tiger dane 
        List<Bitmap> actimag12 = new List<Bitmap>();
        tdance td = new tdance();
       



        List<egg> eg = new List<egg>();
        List<doubleb> db = new List<doubleb>();
        singleb sb = new singleb();
        List<poison> po = new List<poison>();
        List<fire>  F = new List<fire>();//deno bull
        List<Rock> ro = new List<Rock>();
        Actor la = new  Actor(); 
        goralla G = new goralla();
        ActorL lal = new ActorL();
        snake s=new snake();
        lion l1= new lion();
        lionl l2 = new lionl();
        ball b1 = new ball();
        denasor D= new denasor(); 
        laser ll= new laser();
        Bitmap offimage;
        int xcut = 0;
        int ycut = 0;
        int countt = 0;
        int count = 0;//for eggs in timer
        int FlagShape = 1;//for tiger
        int FlagShape2 = 2;//for lion
        int counts = 0;
        int flagshape3 = 0;
        int tigerlife = 1000;
        int glife = 18;
        int FlagGravity = 1;
        int countg = 0;
        int flaglaser = 0;
        int flagdeno = 0;
        int countdeno = 0;
        int flagdeno2 = 0;//fordeno laser
        int flageee = 1;
        int countee = 0;
        int flagmove = 0;
        int flagsingle = 1;
        int countdance = 0;

        

        Random r = new Random();
    
        Bitmap T = new Bitmap("Door.jpg");
        Bitmap loo = new Bitmap("lose.jpg");
        Bitmap R = new Bitmap("rock.png");

        Bitmap B = new Bitmap("Balll.png");
        Bitmap lad = new Bitmap("lad.png");

        Bitmap bk = new Bitmap("bk2.jpg");
        Bitmap smile = new Bitmap("TIGERSMILE.jpg");
        Bitmap gsmile = new Bitmap("gsmile.jpg");
        Bitmap sr = new Bitmap("sr.png");
        Bitmap dl = new Bitmap("dl.png");
        Bitmap sleepydeno = new Bitmap("l14.png");
        Bitmap eee = new Bitmap("eee.png");
        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(800, 675);
            Paint += Form1_Paint;
            KeyDown += Form1_KeyDown;
            MouseDown += Form1_MouseDown;
            MouseUp += Form1_MouseUp;
            KeyUp += Form1_KeyUp;
            MouseMove += Form1_MouseMove;   

            B.MakeTransparent(Color.White);
            Timer t = new Timer();
            t.Start();
            t.Tick += T_Tick;
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            // Handle the mouse move event here
            // You can access the mouse coordinates using e.X and e.Y properties
            // Example:
            int mouseX = e.X;
            int mouseY = e.Y;

            // Perform actions based on the mouse movement
            // ...
        }


        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                FlagGravity= 1;
              
            }
            if(e.KeyCode==Keys.L)
            {
                flaglaser = 0;
                
                    ll.y2 = 1000;

                
            }



            
        }

        private void T_Tick(object sender, EventArgs e)
        {
            countdance++;
            if(countdance==3)
            {
                td.indeximg++;
                if(td.indeximg>7)
                {
                    td.indeximg= 0;
                }
                countdance = 0;
            }
            if (flagsingle == 1)
            {
                sb.x = la.x + 120;
                sb.y = la.y + 20;
            }
            count++;
            countt++;
            counts++;
            countg++;
            countdeno++;
            countee++;
            if(countee==15)
            {

                
                    if(flagmove==1)
                    {
                    FlagGravity= 0;
                       if(la.x<500)
                        {
                            la.x += 20;
                            s.x += 20;
                            FlagGravity = 0;
                        }
                    if (la.y > Height - 520)
                    {
                        la.y -= 20;
                        s.y -= 20;

                    }

                    else
                    {
                        flagmove = 0;
                    }
                      
                       
                        
                    }
                
                countee = 0;
            }
            if(countdeno==30)
            {
                D.indeximg++;
                
                //count---- by the deno
                    //  D.x + 100, D.y + 60,D.x - 200,D.y + 140
                    if (la.x > D.x - 200 && D.x +100 > la.x + 120
                       && D.indeximg == 1)
                    {
                        tigerlife--;
                    }
                
                if (D.indeximg==1)
                {
                    flagdeno2 = 1;

                }
                else
                {
                    flagdeno2= 0;
                }
                if (D.indeximg > 1)
                {
                    D.indeximg = 0;
                }
                //g attacks
                if (flagshape3 == 3)
                {


                    G.indeximg++;
                    if (G.indeximg > 2)
                    {
                        G.indeximg = 0;
                    }

                    if (G.indeximg == 2)
                    {
                        Rock pnn2 = new Rock();
                        pnn2.x = G.x + 30;
                        pnn2.y = G.y + 10;
                        ro.Add(pnn2);
                    }
                }
       
                countdeno=0;
            }
            if(countg==3)
            {
                //DENO MOVE
               



                if (sb.flagdraw==1)
                {
                    if(sb.x<la.x+300)
                    {
                        sb.x += 35;
                    }
                    else
                    {
                        sb.flagdraw = 0;
                        sb.x = la.x + 120;
                    }
                }
                //for double bullet
                for(int i=0;i<db.Count;i++)
                {
                    if (db[i].flagdraw==1)
                    {
                        if (db[i].x>=-20)
                        {
                            db[i].x -= 20 ;
                        }
                        else
                        {
                            db[i].flagdraw = 0;
                            db[i].x = 1000;
                       }
                    }
                   
                }
                if (FlagGravity == 1)
                {
                    if (la.y > Height - 520 || la.x > 530)
                    {
                        
                            if (
                                la.x > 300 && la.y < Height - 270)
                            {
                                la.y += 5;
                            }
                            if (
                                la.x < 230 && la.y < Height - 100)
                            {
                                la.y += 5;
                            }
                            if(la.y<Height-100&&la.y>Height-270&&la.x>230)
                            {
                                la.y += 5;  
                            }
                        


                      
                    }
                    else if (la.y != Height - 520)
                    {
                        la.y += 5;
                    }
                }

                countg =0;
            }
            if(counts==3)
            {
                //killing birds
                for (int i = 0; i < b.Count; i++)
                {
                    
                    if (b[i].x < ll.x && b[i].x + 200 > ll.x&&ll.y2==0)
                    {
                        b[i].fd = 0;
                    }
                }
                //killing snake
                for (int i = 0; i < db.Count; i++)
                {

                    if (db[i].x < s.x&&la.y<Height-250)
                    {
                        flageee = 0;
                    }
                    if (db[i].x < G.x && la.y <= Height - 450)
                    {
                        glife--;
                    }
                }
                //KILLING G
               
                s.indeximg++;
                if(s.indeximg>2)
                {
                    s.indeximg= 0;
                }
                if(s.indeximg==2)
                {
                    poison pnn =new poison();
                    pnn.x = s.x+30;
                    pnn.y=s.y+10;
                    po.Add(pnn);
                }
                for(int i=0;i<po.Count;i++)
                {
                    if (po[i].x<800)
                    {
                        po[i].x+=50;
                        if(la.y<=Height-270&&la.y>Height-300)
                        {
                            if (po[i].x > la.x && po[i].x<la.x+30)
                            {
                                tigerlife--;
                            }
                        }
                    }
                    else
                    {
                        po[i].flagdraw = 0;
                        po[i].x = -200;
                    }
                }
                // for g attack
                if (flagshape3 == 3)
                {
                    
                    for (int i = 0; i < ro.Count; i++)
                    {
                        if (ro[i].x < 500)
                        {
                            ro[i].x += 20;
                        }
                        else
                        {
                            ro[i].flagdraw = 0;
                            ro[i].x = -200;
                        }
                        if (ro[i].x > la.x &&la.y<Height-400)
                        {
                            tigerlife-=5;
                        }
                    }
                }
                counts = 0;
            }
            if(countt==5)
            {
                //when g attacks t
                if (la.y <= Height - 520)
                {
                    flagshape3 = 3;
                }
               
              
                if (l1.x<300)
                {
                    FlagShape2= 2;
                   
                }
               else if(l1.x>500)
                {
                    FlagShape2 = 1;
                }
                if(FlagShape2==1)
                {
                    l1.x -= 20;
                    l1.indeximg++;
                    if (l1.indeximg > 1)
                    {
                        l1.indeximg = 0;
                    }
                }
                if (FlagShape2 == 2)
                {
                    l1.x += 20;
                    l2.indeximg++;
                    if (l2.indeximg > 1)
                    {
                        l2.indeximg = 0;
                    }
                }
                if (G.x <= 0&&flagshape3!=3)
                {
                    flagshape3 = 2;

                }
                else if (G.x > 400)
                {
                    flagshape3 = 1;
                }
                if (flagshape3 == 1)
                {
                    G.x -= 10;
                    G .indeximg++;
                    if (G.indeximg > 1)
                    {
                        G.indeximg = 0;
                    }
                }
                if (flagshape3 == 2&&flagshape3!=3)
                {
                    G.x += 10;
                    G.indeximg++;
                    if (G.indeximg > 1)
                    {
                        G.indeximg = 0;
                    }
                }



                for (int i = 0; i < b.Count; i++)
                {
                    if (b[i].x < 600)
                    {
                        b[i].x += r.Next(0, Width);
                     }
                    if (b[i].x >600)
                    {
                        b[i].x -= r.Next(0, Width);
                    }


                    b[i].indeximg++;

                    if (b[i].indeximg > 2)
                    {
                        b[i].indeximg = 0;
                    }
                   

                }



                countt = 0;
            }
            if(count==50)
            {
                for(int i=0;i< b.Count;i++)
                {
                    if (b[i].fd == 1)
                    {
                        egg pnn = new egg();
                        pnn.x = b[i].x;
                        pnn.y = b[i].y + 100;
                        pnn.speed = r.Next(20, 30);
                        eg.Add(pnn);
                    }
                  
                }

                count = 0;
            }
            for (int i = 0; i < eg.Count; i++)
            {
                eg[i].y += eg[i].speed;
                eg[i].indeximg++;
                if (eg[i].indeximg>1)
                { 
                    eg[i].indeximg = 0;
                }
                if (eg[i].y>la.y&&eg[i].y < la.y+20)
                {
                    if (eg[i].x > la.x && eg[i].x <la.x+120)
                    {
                        tigerlife--;
                    }
                }
/////////////////////////////////////////////////////////////////////////////////
            }
            if(la.x>100&&la.x<220&&la.y>=Height-100)
            {
                b1.y = Height-200;
                tigerlife -= 1;

            }
            if(la.x>180&&flagdeno!=3)
            {
                flagdeno = 1;
            }
            if (flageee == 0)
            {
                if (la.x > 230 && la.x < 350)
                {
                    flagmove = 1;


                }
            }
            if(sb.x>530)
            {
                flagdeno = 3;
            }
          
            Drawdoublebuffer(this.CreateGraphics());

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.D)
            {
                if (FlagShape == 2)
                {
                   doubleb pnn =new doubleb ();
                    pnn.x = la.x;
                    pnn.y=la.y+20;
                    pnn.flagdraw = 1;
                    db.Add(pnn);
                }
            }
            if(e.KeyCode==Keys.S)
            {
                flagsingle = 0;
                if (FlagShape==1)
                {
                    sb.flagdraw =1;
                }
            }
           if(e.KeyCode==Keys.Right)
            {
                FlagShape = 1;
                FlagGravity = 1;

                la.x += 5;
                la.indeximg++;
                xcut+=5;
                if(la.indeximg>1)
                {
                    la.indeximg = 0;
                }
                if(xcut>400)
                {
                    xcut-= 5;
                }
                if (la.x > 675)
                {
                    la.x-=5;
                }

            }
            if (e.KeyCode == Keys.Left)
            {
                FlagShape = 2;
                FlagGravity = 1;

                la.x -= 5;

                lal.indeximg++;
                xcut -= 5;
                if (la.x <0)
                {
                    la.x += 5;
                }
                if (xcut < 0)
                {
                    xcut += 5;
                }
                if (lal.indeximg > 1)
                {
                    lal.indeximg = 0;
                }
            }
            if(e.KeyCode==Keys.Space)
            {
                FlagGravity= 0; 

                if (la.y > Height - 270)
                {
                    if (la.y > Height - 165)
                    {
                        la.y -= 5;
                        if(FlagShape==1)
                        {
                            la.x+=5;
                        }
                        else
                        {
                            la.x-=5;
                        }
                       
                    }
                }
                else
                {

                    if (la.y > Height - 520)
                    {
                        if (la.y > Height - 430)
                        {
                            la.y -= 5;
                            if (FlagShape == 1)
                            {
                                la.x += 5;
                            }
                            else
                            {
                                la.x -= 5;
                            }
                        }
                    }
                    else
                    {

                        la.y -= 120;
                    }
                }
            }
            if(e.KeyCode==Keys.Up)
            {
                if (la.x > 600)
                {
                    FlagShape = 3;
                    FlagGravity = 0;
                    la.y -= 20;
                }

            }
            if (e.KeyCode == Keys.Down)
            {
                if (la.x > 600)
                {
                    FlagShape = 3;
                    FlagGravity = 0;
                    la.y += 20;
                }

            }
            if(e.KeyCode==Keys.L)
            {
                flaglaser = 1;
                ll.y2 = 0;

            }
          
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
       
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            offimage = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);
            

            la.x = 0;
            la.y=Height-100;
            l1.x = 500;
            l1.y=Height-120;
            l2.x = 500;
            l2.y = Height - 120;
            s.x = 300;
            s.y = Height-275;
            G.x = 0;
            G.y=Height-530; 

            D.x = 400;
            D.y = Height - 200;
            td.x = 300;
            td.y=200;

            //g.DrawLine(Pens.Red, la.x + 110, la.y, la.x + 110, 0);

            //  g.DrawLine(Pens.Red, la.x, la.y, la.x, 0);



            //  D.x + 100, D.y + 60,D.x - 200,D.y + 140
            //flag when g attacks t





            for (int i = 1; i < 3; i++)
                {
                    Bitmap bim = new Bitmap((i).ToString() + ".png");
                    bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                    actimag.Add(bim);
                }
            //for the denasor attacks
            for (int i = 1; i < 3; i++)
            {
                Bitmap bim = new Bitmap("l1"+(i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag11.Add(bim);
            }

            for (int i = 1; i < 3; i++)
            {
                Bitmap bim = new Bitmap("e"+(i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag4.Add(bim);
            }
            for (int i = 1; i < 3; i++)
            {
                Bitmap bim = new Bitmap("g" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag8.Add(bim);
            }

            for (int i = 1; i < 4; i++)
            {
                Bitmap bim = new Bitmap("s" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag7.Add(bim);
            }
            for (int i = 1; i < 3; i++)
            {
                Bitmap bim = new Bitmap("l" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag5.Add(bim);
            }
            //i will take this for g
            for (int i = 3; i < 5; i++)
            {
                Bitmap bim = new Bitmap("l" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag6.Add(bim);
            }
            //g attacks
            for (int i = 1; i < 4; i++)
            {
                Bitmap bim = new Bitmap("A" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag10.Add(bim);
            }
            for (int i = 3; i < 5; i++)
            {
                Bitmap bim = new Bitmap("g" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag9.Add(bim);
            }

            for (int i = 5; i < 7; i++)
                {
                    Bitmap bim = new Bitmap((i).ToString() + ".png");
                    bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                    actimag2.Add(bim);
                }
            for (int i = 1; i < 4; i++)
            {
                Bitmap bim = new Bitmap("b"+(i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(255, 255, 255));
                actimag3.Add(bim);
            }
            for(int i=0;i<10;i++)
            {
                Bird pnn = new Bird();
                pnn.x = r.Next(0, Width);
                pnn.y = 0;
               b.Add(pnn);
            }

            //tiger dance
            for (int i = 1; i < 9; i++)
            {
                Bitmap bim = new Bitmap("d" + (i).ToString() + ".png");
                bim.MakeTransparent(Color.FromArgb(0, 255, 0));
                actimag12.Add(bim);
            }

        }
        void Drawdoublebuffer(Graphics g) //main
        {
            Graphics g2 = Graphics.FromImage(offimage);
            Drawscene(g2);
            g.DrawImage(offimage, 0, 0);
        }
        void Drawscene(Graphics g) //main
        {
            g.Clear(Color.White);
            // g.DrawImage(bk, 0, 0, 300, 300);
            g.DrawImage(bk, new Rectangle(0, 0, this.ClientSize.Width, this.ClientSize.Height),
                           new Rectangle(xcut, ycut, this.ClientSize.Width, this.ClientSize.Height),
                         GraphicsUnit.Pixel);
if(tigerlife>0&&glife>0)
{ 

            if (FlagShape == 1)
            {
                ll.x = la.x + 110;
                ll.y = la.y;
                ll.x2 = la.x + 110;

            }
            if (FlagShape == 2)
            {
                ll.x = la.x;
                ll.y = la.y;
                ll.x2 = la.x;
             
            }
            //lader
            int f = 0;
            for (int i = 0; i < 5; i++)
            {
                g.DrawLine(Pens.Orange, 700, Height - 200 + f, 800, Height - 200 + f);
                f += 20;
            }
            //denoattacks
            if(flagdeno==1)
            {
                g.DrawImage(actimag11[D.indeximg], D.x, D.y, 300, 200);
                if(flagdeno2==1)
                {
                    g.DrawLine(Pens.Red, D.x+100 ,D.y+60,D.x-200,D.y+140);
                }
            }
            else if(flagdeno==0) 
            {
                g.DrawImage(sleepydeno, D.x, D.y, 300, 200);
            }
            if (FlagShape == 3)
            {
                g.DrawImage(lad, la.x-80, la.y-80, 300, 200);
            }
            if (FlagShape == 1)
            {
                g.DrawImage(actimag[la.indeximg], la.x, la.y, 120, 75);
            }
            if (FlagShape == 2)
            {
                g.DrawImage(actimag2[lal.indeximg], lal.x = la.x, lal.y = la.y, 120, 75);
            }
            
            if (flagshape3 == 2)
            {
                g.DrawImage(actimag8[G.indeximg], G.x, G.y, 200, 100);
            }
            if (flagshape3 == 1)
            {
                g.DrawImage(actimag9[G.indeximg], G.x, G.y, 200, 100);
            }
            if (flagshape3 == 3)
            {
                g.DrawImage(actimag10[G.indeximg], G.x = 0, G.y, 200, 100);
            }

            for (int i = 0; i < b.Count; i++)
            {
                if (b[i].fd == 1)
                {
                    g.DrawImage(actimag3[b[i].indeximg], b[i].x, b[i].y, 200, 100);
                }
            }
            for (int i = 0; i < eg.Count; i++)
            {

                g.DrawImage(actimag4[eg[i].indeximg], eg[i].x, eg[i].y, 30, 20);

            }

            g.DrawImage(T, 100, Height - 50, 120, 25);
            g.DrawImage(B, b1.x, b1.y, 120, 200);
            g.FillRectangle(Brushes.Black, 700, Height - 200, 20, 100);
            g.FillRectangle(Brushes.Black, 300, Height - 200, 400, 20);
            g.FillRectangle(Brushes.Black, 0, Height - 450, 610, 30);
            //snakee
            if (flageee == 1)
            {
                g.DrawImage(actimag7[s.indeximg], s.x, s.y, 150, 75);
                for (int i = 0; i < po.Count; i++)
                {
                    if (po[i].flagdraw == 1)
                    {
                        g.FillEllipse(Brushes.YellowGreen, po[i].x, po[i].y, 15, 15);
                    }

                }
            }
            else
            {
                g.DrawImage(eee, s.x, s.y, 150, 75);
            }
            g.DrawImage(smile, la.x, la.y - 30, 20, 20);
            g.DrawImage(gsmile, 0, Height - 450, 30, 30);
           
            //for the pison

           
            for (int i = 0; i < ro.Count; i++)
            {
                if (ro[i].flagdraw == 1)
                {
                    g.DrawImage(R, ro[i].x, ro[i].y, 50, 25);
                }

            }
            int z = 30;
            int z2 = 30;
            for (int i = 0; i < tigerlife; i++)
            {
                g.FillEllipse(Brushes.Orange, la.x + z, la.y - 30, 15, 15);
                z += 30;

            }
            for (int i = 0; i < glife; i++)
            {
                g.FillEllipse(Brushes.Red, z2, Height - 440, 15, 15);
                z2 += 30;

            }
            if (flaglaser == 1)
            { 
                    g.DrawLine(Pens.Red, ll.x, ll.y, ll.x2, ll.y2);
            }
            if (sb.flagdraw == 1)
            {
                g.DrawImage(sr, sb.x, sb.y, 50, 20);



            }
                for (int i = 0; i < db.Count; i++)
                {
                    if (db[i].flagdraw == 1)
                    {

                        g.DrawImage(dl, db[i].x, db[i].y, 50, 20);
                        g.DrawImage(dl, db[i].x, db[i].y + 20, 50, 20);



                    }
}  
               
            }
           else if (tigerlife > 0&&glife<=0)
            {
                g.DrawImage(actimag12[td.indeximg], td.x, td.y, 500, 400);
            }
            else
            {
                g.DrawImage(loo, 0, 0, 800, 675);
            }
        }
    }
}
